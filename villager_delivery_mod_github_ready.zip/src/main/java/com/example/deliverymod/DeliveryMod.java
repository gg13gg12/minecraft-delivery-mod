
package com.example.deliverymod;

import net.minecraftforge.fml.common.Mod;

@Mod("deliverymod")
public class DeliveryMod {
    public DeliveryMod() {
        System.out.println("Villager Delivery Mod loaded!");
    }
}
